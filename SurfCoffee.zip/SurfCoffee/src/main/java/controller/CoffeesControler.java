/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.Coffee;
import views.CreateCoffee;



/**
 *
 * @author alunopa
 */
public class CoffeesControler implements ActionListener{
    private CreateCoffee createCoffee;
    public CoffeesControler(CreateCoffee createCoffee){
        this.createCoffee = createCoffee;
        this.createCoffee.btnSave.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.createCoffee.btnSave){
            Coffee coffee = new Coffee();
            coffee.setBrand(this.createCoffee.txtBrand.getText());
            
            String precoString = this.createCoffee.txtPrice.getText();
            float price = Float.parseFloat(precoString);
            coffee.setPrice(price);
            
            coffee.setWeight(Float.parseFloat(this.createCoffee.txtWeight.getText()));
            JOptionPane.showMessageDialog(null, "Marca: " + coffee.getBrand() + "\nPreço: " + coffee.getPrice() + "\nBrand: " + coffee.getWeight());
        }
    }
}
